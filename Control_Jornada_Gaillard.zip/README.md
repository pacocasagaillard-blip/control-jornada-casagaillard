# Control de jornada de Casa Gaillard — prototipo 0.1

Este paquete contiene un punto de partida Flutter para Android y iPhone.

## Incluye en este prototipo
- Pantalla en castellano con selección de empresa (Casa Gaillard / Segundo empleo).
- Registro manual de conducción, otros trabajos, disponibilidad y descanso.
- Hora de inicio/fin, historial y totales por actividad.
- Solicitud de ubicación GPS mientras se usa la aplicación.
- Comandos de voz básicos mediante botón de micrófono.
- Guardado local en el teléfono.

## Lo que todavía NO está implementado
- Sincronización real en la nube entre Android y iPhone: requiere crear un proyecto Firebase/Supabase, configurar autenticación y reglas de seguridad.
- Notificaciones fiables en segundo plano y detección automática de paradas.
- Firma/publicación en Google Play o App Store.
- Cálculo legal definitivo de descanso y hora de inserción de tarjeta.

## Importante sobre el tacógrafo
El GPS no puede saber por sí solo si una parada es descanso, disponibilidad o trabajo: la aplicación pide confirmación. Tampoco debe recomendar una hora de inserción de tarjeta sin disponer de los registros completos del tacógrafo, las actividades de ambos empleos y las reglas aplicables. Este prototipo NO sustituye el tacógrafo ni una comprobación legal.

## Cómo ejecutar
1. Instala Flutter SDK y Android Studio (para Android) o Xcode en macOS (para iOS).
2. En esta carpeta ejecuta `flutter pub get`.
3. Ejecuta `flutter run`.
4. Acepta los permisos de ubicación y micrófono cuando se soliciten.

Para compilar iOS se necesita un Mac con Xcode. Antes de usar en producción hay que añadir privacidad, cifrado, copias de seguridad, sincronización autenticada y pruebas en los dos teléfonos.


## Compilar el APK sin ordenador (desde el Motorola o iPhone)
Se ha añadido un flujo de GitHub Actions en `.github/workflows/android-apk.yml`.
1. Crea una cuenta gratuita en GitHub desde el navegador del móvil.
2. Crea un repositorio nuevo y sube el contenido de esta carpeta (no el ZIP como único archivo: hay que subir los archivos y carpetas del proyecto).
3. Abre la pestaña **Actions**, selecciona **Compilar APK Android** y pulsa **Run workflow** (si no se inicia automáticamente).
4. Cuando termine correctamente, abre la ejecución y descarga el artefacto `control-jornada-casa-gaillard-apk`.
5. Dentro estará `app-release.apk`, que puedes descargar e instalar en el Motorola.

La configuración de GitHub puede cambiar y la subida de muchos archivos desde móvil puede resultar incómoda. No compartas públicamente datos de jornadas reales ni credenciales. Esta compilación solo crea el APK; no activa sincronización en nube.
