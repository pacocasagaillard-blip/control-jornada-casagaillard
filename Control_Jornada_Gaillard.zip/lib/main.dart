import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';

void main() => runApp(const JornadaApp());

class JornadaApp extends StatelessWidget {
  const JornadaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Control de jornada de Casa Gaillard',
    theme: ThemeData(colorSchemeSeed: const Color(0xff245b45), useMaterial3: true),
    home: const JornadaHome(),
  );
}

class Registro {
  final String empresa, actividad;
  final DateTime inicio;
  DateTime? fin;
  double? lat, lon;
  Registro(this.empresa, this.actividad, this.inicio, {this.fin, this.lat, this.lon});
  Map<String, dynamic> toJson() => {
    'empresa': empresa, 'actividad': actividad,
    'inicio': inicio.toIso8601String(), 'fin': fin?.toIso8601String(),
    'lat': lat, 'lon': lon
  };
  static Registro fromJson(Map<String, dynamic> j) => Registro(
    j['empresa'], j['actividad'], DateTime.parse(j['inicio']),
    fin: j['fin'] == null ? null : DateTime.parse(j['fin']),
    lat: (j['lat'] as num?)?.toDouble(), lon: (j['lon'] as num?)?.toDouble());
}

class JornadaHome extends StatefulWidget {
  const JornadaHome({super.key});
  @override
  State<JornadaHome> createState() => _JornadaHomeState();
}

class _JornadaHomeState extends State<JornadaHome> {
  final List<Registro> registros = [];
  final empresas = ['Casa Gaillard', 'Segundo empleo'];
  String empresa = 'Casa Gaillard';
  String? actividadActual;
  DateTime? inicioJornada;
  Position? posicion;
  StreamSubscription<Position>? gpsSub;
  final stt.SpeechToText voz = stt.SpeechToText();
  bool escuchando = false;

  @override
  void initState() { super.initState(); cargar(); }

  Future<void> cargar() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('registros') ?? '[]';
    final list = (jsonDecode(raw) as List).cast<Map<String, dynamic>>();
    setState(() => registros.addAll(list.map(Registro.fromJson)));
  }

  Future<void> guardar() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('registros', jsonEncode(registros.map((r) => r.toJson()).toList()));
  }

  Future<void> iniciarJornada() async {
    inicioJornada ??= DateTime.now();
    await iniciarGps();
    setState(() {});
  }

  Future<void> iniciarGps() async {
    if (!await Geolocator.isLocationServiceEnabled()) return;
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) return;
    posicion = await Geolocator.getCurrentPosition();
    gpsSub ??= Geolocator.getPositionStream(
      locationSettings: const LocationSettings(accuracy: LocationAccuracy.medium, distanceFilter: 100))
      .listen((p) { posicion = p; });
  }

  Future<void> cambiarActividad(String actividad) async {
    if (inicioJornada == null) await iniciarJornada();
    if (registros.isNotEmpty && registros.last.fin == null) registros.last.fin = DateTime.now();
    registros.add(Registro(empresa, actividad, DateTime.now(), lat: posicion?.latitude, lon: posicion?.longitude));
    actividadActual = actividad;
    await guardar(); setState(() {});
  }

  Future<void> finalizarJornada() async {
    if (registros.isNotEmpty && registros.last.fin == null) registros.last.fin = DateTime.now();
    inicioJornada = null; actividadActual = null;
    await guardar(); await gpsSub?.cancel(); gpsSub = null; setState(() {});
  }

  Future<void> comandoVoz() async {
    final ok = await voz.initialize();
    if (!ok) { aviso('El reconocimiento de voz no está disponible.'); return; }
    setState(() => escuchando = true);
    voz.listen(localeId: 'es_ES', onResult: (r) {
      if (!r.finalResult) return;
      final t = r.recognizedWords.toLowerCase();
      if (t.contains('inicia') || t.contains('empezar jornada')) iniciarJornada();
      else if (t.contains('finaliza') || t.contains('terminar jornada')) finalizarJornada();
      else if (t.contains('descanso')) cambiarActividad('Descanso');
      else if (t.contains('disponibilidad')) cambiarActividad('Disponibilidad');
      else if (t.contains('conducción') || t.contains('conducir')) cambiarActividad('Conducción');
      else if (t.contains('trabajo')) cambiarActividad('Otros trabajos');
      else aviso('No he reconocido el comando: $t');
      setState(() => escuchando = false);
      voz.stop();
    });
  }

  void aviso(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));

  Duration total(String a) {
    var d = Duration.zero;
    for (final r in registros.where((x) => x.actividad == a)) {
      d += (r.fin ?? DateTime.now()).difference(r.inicio);
    }
    return d;
  }
  String horas(Duration d) => '${d.inHours} h ${(d.inMinutes % 60).toString().padLeft(2, '0')} min';

  @override
  void dispose() { gpsSub?.cancel(); voz.stop(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final fmt = DateFormat('dd/MM/yyyy HH:mm');
    return Scaffold(
      appBar: AppBar(title: const Text('CONTROL DE JORNADA'), centerTitle: true),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        const SizedBox(height: 4),
        const Text('CASA GAILLARD, S.A.', textAlign: TextAlign.center,
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, letterSpacing: 1)),
        const Text('Control de jornada de Casa Gaillard', textAlign: TextAlign.center),
        const SizedBox(height: 22),
        DropdownButtonFormField<String>(
          value: empresa, decoration: const InputDecoration(labelText: 'Empresa', border: OutlineInputBorder()),
          items: empresas.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
          onChanged: (v) => setState(() => empresa = v ?? empresa)),
        const SizedBox(height: 14),
        FilledButton.icon(onPressed: iniciarJornada, icon: const Icon(Icons.play_arrow),
          label: const Padding(padding: EdgeInsets.all(12), child: Text('INICIAR JORNADA'))),
        OutlinedButton.icon(onPressed: comandoVoz, icon: Icon(escuchando ? Icons.mic : Icons.mic_none),
          label: Text(escuchando ? 'ESCUCHANDO…' : 'COMANDOS DE VOZ')),
        const SizedBox(height: 12),
        if (actividadActual != null) Card(child: ListTile(
          title: const Text('Actividad actual'), subtitle: Text('$actividadActual · $empresa'),
          trailing: const Icon(Icons.circle, color: Colors.green))),
        const Text('REGISTRAR ACTIVIDAD', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final a in ['Conducción', 'Otros trabajos', 'Disponibilidad', 'Descanso'])
            ActionChip(label: Text(a), onPressed: () => cambiarActividad(a)),
        ]),
        const SizedBox(height: 14),
        OutlinedButton.icon(onPressed: finalizarJornada, icon: const Icon(Icons.stop_circle_outlined),
          label: const Text('FINALIZAR JORNADA')),
        const Divider(height: 30),
        const Text('TOTALES REGISTRADOS', style: TextStyle(fontWeight: FontWeight.bold)),
        for (final a in ['Conducción', 'Otros trabajos', 'Disponibilidad', 'Descanso'])
          ListTile(dense: true, title: Text(a), trailing: Text(horas(total(a)))),
        const Divider(),
        const Text('HISTORIAL', style: TextStyle(fontWeight: FontWeight.bold)),
        for (final r in registros.reversed.take(30))
          ListTile(dense: true, title: Text('${r.actividad} · ${r.empresa}'),
            subtitle: Text('${fmt.format(r.inicio)} – ${r.fin == null ? "En curso" : fmt.format(r.fin!)}')),
        const SizedBox(height: 12),
        const Text('Aviso: prototipo de registro. No sustituye al tacógrafo ni determina legalmente cuándo insertar la tarjeta.',
          style: TextStyle(fontSize: 12, color: Colors.redAccent)),
      ]),
    );
  }
}
